package scytale;

/**
 */
public class CryptographicMethod 
{
    
}
